from pathlib import Path
import os, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
p=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve(); os.chdir(p)
versions=('binary','hole_key','scan')
for v in versions:
    shutil.copytree(root/'src',p/v/'src',dirs_exist_ok=True)
    shutil.copy2(p/'snapshots'/v/'scheduler.hpp',p/v/'src/core/runtime/scheduler.hpp')
(p/'apps/cli').mkdir(parents=True,exist_ok=True)
for name in ('tai_xu_runtime','mo_wen_runtime'):
    shutil.copy2(root/'apps/cli'/(name+'.cpp'),p/'apps/cli')
def build(item):
    cc,v=item
    subprocess.run([{'gcc':'g++','clang':'clang++'}[cc],'-O3','-DNDEBUG','-std=gnu++26','-I',str(p/v),str(p/'fights.cpp'),'-o',str(p/(cc+'-'+v+'.exe'))],check=True)
with ThreadPoolExecutor(4) as e: list(e.map(build,((cc,v) for cc in ('gcc','clang') for v in versions)))
for script in ('final-verify.py','final-time.py','final-cli.py'):
    subprocess.run([sys.executable,str(p/script)],check=True)
