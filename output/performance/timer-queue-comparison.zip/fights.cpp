#include "src/class/tai_xu_jian_yi/runtime_rules.hpp"
#include "src/class/mo_wen/runtime_rules.hpp"
#include "src/core/runtime/batch.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <fcntl.h>
#include <io.h>
using namespace JX3DPS;
using namespace JX3DPS::runtime;
namespace tx = tai_xu;
namespace mw = mo_wen;
struct Fired { tick_t frame; DeadlineQueue::TimerId id; TimerHandle handle; };
template<class Rules> struct Traced : Rules {
    using Rules::Rules;
    std::vector<Fired>* trace;
    template<class Engine> void OnTimer(Engine& e, TimerHandle h, DeadlineQueue::TimerId id){
        trace->push_back({e.GetState().now,id,h});
        Rules::OnTimer(e,h,id);
    }
};
struct Bytes {
    std::vector<char> bytes;
    template<class... V> void append(const V&... v){
        auto add=[this]<class T>(const T& x){auto f=reinterpret_cast<const char*>(&x);bytes.insert(bytes.end(),f,f+sizeof(x));};
        (add(v),...);
    }
};
std::string mode;
unsigned iterations;
template<class Config> void run(const char* name,const Config& c,std::string_view text,CompileOptions opts){
    auto [macro,errors]=MacroCompiler::Compile(text,opts);if(!errors.empty())throw std::runtime_error("macro");
    using Rules=typename Config::RuntimeModule::Rules;
    auto data=PrepareConfiguration(c);
    if(mode=="trace"){
        std::vector<Fired> fired; Traced<Rules> rules(data); rules.trace=&fired;
        Simulation<Traced<Rules>> sim(macro.program,rules);Bytes buf;
        uint64_t timers=0,hits=0,mutations=0,same=0;
        for(unsigned i=0;i<iterations;++i){
            fired.clear();buf.bytes.clear();sim.Start(4800,IterationSeed(42,i));sim.Run();
            auto& log=sim.Log();auto total=sim.TotalDamage();buf.append(i,total,uint32_t(fired.size()),uint32_t(log.Size()),uint32_t(log.Mutations().size()));
            tick_t previous=-1;
            for(auto& e:fired){buf.append(e.frame,e.id,e.handle.kind,e.handle.slot,e.handle.target);same+=e.frame==previous;previous=e.frame;}
            for(auto& h:log.Intents()){buf.append(h.frame,h.sequence,h.skill,h.target,h.level,h.outcome,h.random_key,h.base,h.coefficient,h.effect,h.snapshot,h.sub,h.snapshot_version,h.live_version,sim.GetRules().Reduce(h));}
            for(auto& m:log.Mutations())buf.append(m.frame,m.sequence,m.kind,m.slot,m.target,m.a,m.b,m.c);
            auto size=uint32_t(buf.bytes.size());if(std::fwrite(&size,sizeof(size),1,stdout)!=1||std::fwrite(buf.bytes.data(),1,size,stdout)!=size)throw std::runtime_error("write");
            timers+=fired.size();hits+=log.Size();mutations+=log.Mutations().size();
        }
        std::cerr<<name<<" timers="<<timers<<" same="<<same<<" hits="<<hits<<" mutations="<<mutations<<'\n';return;
    }
    Simulation<Rules> sim(macro.program,Rules(data));
    BatchStats warm,stats;
    for(unsigned i=0;i<128;++i){sim.Start(4800,IterationSeed(42,i));sim.Run();warm.Add(sim.TotalDamage(),i);}
    auto start=std::chrono::steady_clock::now();
    for(unsigned i=0;i<iterations;++i){sim.Start(4800,IterationSeed(42,i));sim.Run();stats.Add(sim.TotalDamage(),i);}
    auto end=std::chrono::steady_clock::now();
    std::cout<<name<<' '<<std::fixed<<std::setprecision(5)<<std::chrono::duration<double,std::micro>(end-start).count()/iterations<<' '<<stats.checksum<<' '<<warm.checksum<<'\n';
}

int main(int argc,char** argv){mode=argc>1?argv[1]:"time";iterations=argc>2?std::stoul(argv[2]):2048;if(mode=="trace")_setmode(_fileno(stdout),_O_BINARY);
    constexpr auto txmacro="/cast [nobuff:ziqi&qidian<6] ziqi\n/cast [qidian>=8] wuwu\n/cast bahuang\n/cast sanhuan\n/cast sanchai\n/cast [qidian>=1] wuwu";
    constexpr auto mwmacro="/cast [tnobuff:shang] shang\n/cast [tnobuff:jue] jue\n/cast shuying\n/cast gaoshan\n/cast [buff:qufeng=4] yu\n/cast bianzhi\n/cast biangong";
    tx::Config t; mw::Config m;run("tx",t,txmacro,tx::MacroOptions(false));run("mw",m,mwmacro,mw::MacroOptions(false));
    t.talents=tx::DieRenTalent|tx::WuYi|tx::ShenMai|tx::XuanMen|tx::LieYun|tx::GuChang;t.equipment=tx::WeaponCW|tx::SetAttribute;t.attributes.overcome_base=20000;t.attributes.overcome_by_class=5000;t.team_buffs={{tx::team::JiLei,0,96,1},{tx::team::NongMei,48,96,1},{tx::team::HaoLingSanJun,16,0,48},{tx::team::PoFeng,32,160,1}};
    m.talents=mw::HaoZhong|mw::FeiFan|mw::ShiXiang|mw::ZhengLvHeMing|mw::LiuZhaoTalent|mw::KeMeng;m.equipment=mw::EnchantShoes|mw::EnchantWrist|mw::EnchantBelt|mw::SetAttribute|mw::SetSkill|mw::WeaponCW|mw::WeaponWater;m.team_effects=mw::YouRen|mw::JingMiao;
    run("tx_buffs",t,txmacro,tx::MacroOptions(false)); run("mw_equipped",m,mwmacro,mw::MacroOptions(false));
}
