from pathlib import Path
import concurrent.futures as ft,json,os,subprocess,sys,statistics
D=Path(__file__).resolve().parent;P=D.parent;sys.path.insert(0,str(P.parent));from compare import call
R=lambda f:json.loads(f.read_bytes());S=lambda f,v:f.write_text(json.dumps(v,ensure_ascii=False),'utf8');env=os.environ.copy();env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH'];schools={b['code']:b for b in call(op='schools')};jobs=[]
for k in ['fsj','tlgd','yjj']:
 q=R(P/f'q-{k}-equipped.json');m=schools[k]['macro'];cases={'default':m};
 if k=='yjj':
  cases.update(guard=m.replace('[禅那>2] 拿云式','[禅那>2&buff:拿云] 拿云式'),no_weit='\n'.join(l for l in m.splitlines() if '韦陀献杵' not in l));
 if k=='fsj':cases.update(no_auto='\n'.join(l for l in m.splitlines() if '卷雪刀' not in l),shield0=m)
 for label,text in cases.items():
  request={k:v for k,v in q.items() if k!='buttons'}|dict(iterations=1024,macro=text,zero_shield_prepare=label=='shield0');S(D/f'{k}-{label}-request.json',request);jobs.append((k,label));
def run(job):
 k,label=job;subprocess.run([str(D/'macro.exe'),str(D/f'{k}-{label}-request.json'),str(D/f'{k}-{label}.json')],env=env,check=True);x=R(D/f'{k}-{label}.json');print(k,label,round(x['mean']),round(x['se'],1),x['missing'],x['replies'],x['delays'],x['unresolved'],flush=True)
with ft.ThreadPoolExecutor(max_workers=5) as ex:list(ex.map(run,jobs))
for k in schools.keys() & {'yjj','fsj','tlgd'}:
 q=R(D/f'{k}-default-request.json');r=call(op='batch',scenario=k,macro=q['macro'],config=q['config'],frames=q['frames'],seed='42',iterations=q['iterations'],workers=8);assert 'stats' in r,r;S(D/f'{k}-dll.json',r);x=R(D/f'{k}-default.json');print('verified',k,int(r['stats']['mean_damage']));assert abs(r['stats']['mean_damage']-statistics.mean(x['damages']))<.00001
