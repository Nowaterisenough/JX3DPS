from confirm import *
def common(k):
 a=run(k,'common-gcd',[445,681,682,927,928],512,True);print(k,[(i['h'],i['total_changed']) for i in a[1:]],flush=True)
if __name__=='__main__':
 with ft.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(common,books))
