import json,subprocess,os,sys,concurrent.futures as ft
from pathlib import Path
from zipfile import ZipFile
D=Path(__file__).resolve().parent;env=os.environ.copy();env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH'];src=Path('docs/season50_online_attribute_gains_20261124.zip');read=lambda f:json.loads(f.read_bytes());save=lambda f,x:f.write_text(json.dumps(x,ensure_ascii=False),'utf8');qbase={}
with ZipFile(src) as z:
 Z=lambda f:json.loads(z.read(f));books=Z('gains.json');
 for k in books:
  q=Z(k+'/macro.json')['base'];qbase[k]={key:q[key] for key in ('config','frames','bracer')}|dict(code=k,macro=Z(k+'/macro-source.json'))
def run(k,tag,ratings,n,diagnostic=False,kwargs={}):
 q=qbase[k]|dict(N=n,ratings=ratings,diagnostic=diagnostic,keep=[qbase[k]['config']['attributes']['haste']])|kwargs;ip=D/f'input-{k}-{tag}.json';op=D/f'{k}-{tag}.json';save(ip,q);subprocess.run([str(D/'scan.exe'),str(ip),str(op)],env=env,check=True);return read(op)
def sweep(k):
 rows=run(k,'sweep',list(range(0,2529)),3);b=qbase[k]['config']['attributes']['haste']; edges=[x['h'] for x in rows if x['h']>b and (x['hits_changed'] or x['casts_changed'])]; print(k,b,edges[:3],len(rows),flush=True)
if __name__=='__main__':
 with ft.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(sweep,books))
