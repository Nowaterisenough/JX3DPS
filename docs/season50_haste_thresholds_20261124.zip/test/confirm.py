from run import *
import math
internal=lambda h:min(256,h*1024*10//101079)
step=lambda h,n,r=0:max(1,n*1024//(1024+internal(h)+r))
MAJOR=[9,10,444,445,927,928,1451,1452,2023,2024,2526,2527,2528]
def gear(h):return (12+3*h//444 if h<=444 else 15+2*(h-444)//484 if h<=928 else 17+3*(h-928)//523 if h<=1451 else 20+2*(h-1451)//573 if h<=2024 else 22, sum(h>=i for i in (445,928,1452,2024)))
def changed(row):return row['casts_changed'] or row['hits_changed'] or row['total_changed']
def choices(k):
 q=qbase[k];b=q['config']['attributes']['haste'];s=read(D/f'{k}-sweep.json');es=[i['h'] for i in s if changed(i)];border=next((e for e in es if e>b),2528);width,a,end=max((bb-aa,aa,bb) for aa,bb in zip([0]+es,es));return b,border,a,end
# Validate every internal numerical change and item tier inside the two candidate windows, including all endpoints.
def stages(k):
 b,end,a,hi=choices(k);cand=[h for h in range(1,2529) if internal(h)!=internal(h-1) or gear(h)!=gear(h-1)];
 ratings=sorted(set([b,end-1,end,a,hi-1,hi]+[h for h in cand if b<=h<=end or a<=h<=hi]));rows=run(k,'confirm',ratings,512);edges=[x['h'] for x in rows if x['previous']>=0 and changed(x)];end=min(e for e in edges if b<e<=end); sub=sorted({a,hi}|{e for e in edges if a<e<hi});l,lo,upper=max((y-x,x,y) for x,y in zip(sub,sub[1:]));
 diag=run(k,'actual',[b,end-1,end],512,True);wide=run(k,'wide',[lo,upper-1,upper],512,True);print(k, 'actual',b,end-1,end,diag[1]['total_changed'],diag[1]['hits_changed'],diag[2]['delta'],'wide',lo,upper-1,wide[1]['total_changed'],flush=True);
 if changed(diag[1]) or changed(wide[1]):raise ValueError((k,'plateau failed'))
if __name__=='__main__':
 with ft.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(stages,books))
