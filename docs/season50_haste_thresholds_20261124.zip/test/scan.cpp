#include "src/class/common/runtime_rules.hpp"
#include "src/engine/config_json.hpp"
#include "src/core/runtime/batch_statistics.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <map>
#include <cmath>
using namespace JX3DPS; namespace rt=runtime;namespace s50=rt::season50;using J=nlohmann::json;
struct Hit {int frame,slot,rank,sub,roll;long long amount;bool operator==(const Hit&)const=default;};
struct Trace {long long damage=0;std::vector<std::pair<int,int>> casts;std::vector<Hit> hits;std::vector<rt::StateMutation> mutations;};
struct Traced:public s50::Rules{
 std::vector<std::pair<int,int>>* casts;
 Traced(s50::Preparation p,std::vector<std::pair<int,int>>* c):Rules(p),casts(c){}
 template<class Engine> bool Cast(Engine&e,const rt::MacroLine&l,int pulses=0) {bool ok=Rules::Cast(e,l,pulses);if(ok) casts->emplace_back(e.GetState().now,l.action_slot);return ok;}
};
int main(int argc,char**argv){try{const J q=J::parse(std::ifstream(argv[1]));auto cfg=engine::Scenario(q.at("code").get<std::string>());q.at("config").get_to(cfg);auto book=*cfg.book;cfg.book=&book;if(int n=q.value("bracer",0)){auto it=std::ranges::find(book.skills,"巽·晚山青",&rt::SkillDescriptor::name);if(book.hits.at(it-book.skills.begin()).fixed!=46000)return 3;book.hits[it-book.skills.begin()].fixed=n;}
 std::string macro=q.value("macro",std::string(book.default_macro));auto [compiled,errors]=rt::MacroCompiler::Compile(macro,rt::CatalogMacroOptions(book.Catalog()));if(!errors.empty())throw std::runtime_error(errors[0].message);
 const int N=q.at("N"),F=q.at("frames");std::vector<Trace> history(N);std::vector<std::pair<int,int>> casts;J rows=J::array();int prev=-1;bool diagnostic=q.value("diagnostic",false);std::set<int> keep=q.at("keep").get<std::set<int>>();
 for(int h:q.at("ratings")){cfg.attributes.haste=h;auto prepared=s50::Prepare(cfg);rt::Simulation<Traced> sim(compiled.program,Traced(prepared,&casts),60000,150000);int diffTotals=0,diffHits=0,diffCasts=0,diffStates=0;long double sum=0,delta=0,dsq=0;J first=J::object(), mut=J::object();
  for(int i=0;i<N;++i){casts.clear();sim.Start(F,rt::IterationSeed(42,i));sim.Run();Trace t;t.casts=casts;t.damage=sim.TotalDamage([&](auto&v,auto d){t.hits.push_back({v.frame,v.skill,v.level,v.sub,static_cast<int>(v.outcome),d});});if(diagnostic)t.mutations=sim.Log().Mutations();sum+=t.damage;
   if(prev>=0){auto& old=history[i];auto d=t.damage-old.damage;delta+=d;dsq+=static_cast<long double>(d)*d;diffTotals+=d!=0;diffCasts+=old.casts!=t.casts;if(t.hits!=old.hits){++diffHits;if(diagnostic&&first.empty()){size_t a=0;while(a<t.hits.size()&&a<old.hits.size()&&t.hits[a]==old.hits[a])++a;auto rec=[&](const auto&hs)->J{if(a==hs.size())return nullptr;const auto&x=hs[a];return J::array({x.frame,book.skills[x.slot].name,x.rank,x.sub,x.amount});};first={{"run",i},{"before",rec(old.hits)},{"after",rec(t.hits)}};}}
   if(diagnostic&&old.mutations!=t.mutations){++diffStates;if(mut.empty()){size_t a=0;while(a<old.mutations.size()&&a<t.mutations.size()&&old.mutations[a]==t.mutations[a])++a;auto rec=[&](auto&vs)->J{if(a==vs.size())return nullptr;auto&m=vs[a];std::string_view name{};using M=rt::MutationKind;if(m.kind==M::BUFF)name=book.buffs[m.slot].name;else if(m.kind==M::SKILL_COOLDOWN||m.kind==M::PREPARE||m.kind==M::CASTING||m.kind==M::SKILL_ENERGY)name=book.skills[m.slot].name;return J::array({m.frame,int(m.kind),name,m.a,m.b,m.c});};mut={{"run",i},{"before",rec(old.mutations)},{"after",rec(t.mutations)}};}}}
   history[i]=std::move(t);
  }
  if(diagnostic||diffTotals||diffCasts||diffHits||keep.contains(h)||prev<0){double df=double(delta/N)*16/F;double se=N<2?0:std::sqrt(std::max(0.L,dsq-delta*delta/N)/(N-1)/N)*16/F;rows.push_back({{"h",h},{"previous",prev},{"internal",std::lround(1024*(prepared->haste-1))},{"base_gcd",int(24/prepared->haste)},{"dps",double(sum/N)*16/F},{"delta",df},{"se",se},{"total_changed",diffTotals},{"casts_changed",diffCasts},{"hits_changed",diffHits},{"states_changed",diagnostic?diffStates:-1},{"first_hit",first},{"first_mutation",mut}});}prev=h;
 }
 std::ofstream(argv[2])<<rows.dump();}catch(std::exception&e){std::cerr<<e.what();return 1;}}
