from confirm import *
import copy
pts=[0,9,10,335,336,444,445,466,533,534,681,682,927,928,1046,1047,1125,1126,1451,1452,1786,1787,1875,1876,2023,2024,2339,2340,2527]
for k,macro,tag in [('fsj','/cast 盾刀','16'),('zxg','/cast 太极无极','24'),('lhj','/cast 翼绝云天','32'),('lhj','/cast 浮游天地','20lock')]:
 q=copy.deepcopy(qbase[k]);q['config'].update(equipment=[],precombat=False,talents=[],recipes=[]);q.update(macro=macro,frames=960,N=1,keep=pts,ratings=pts);f=D/f'solo-{tag}-in.json';o=D/f'solo-{tag}.json';save(f,q);subprocess.run([str(D/'skills.exe'),str(f),str(o)],env=env,check=True);print(tag,[(x['h'],x['gcdObserved']) for x in read(o) if x['h'] in (335,336,444,445,681,682,927,928)],flush=True)
