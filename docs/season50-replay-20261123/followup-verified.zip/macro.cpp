#include "src/class/common/runtime_rules.hpp"
#include "src/engine/config_json.hpp"
#include "src/core/runtime/batch_statistics.hpp"
#include <fstream>
#include <iostream>
#include <map>
#include <set>
namespace rt=JX3DPS::runtime; namespace s50=rt::season50; using json=nlohmann::json; using std::string;
struct Counters {std::map<string,int> accepted,replies;std::map<int,int> delays;int pending=-1;int rejected=0;int unresolved=0;};
struct Tracked:public s50::Rules {
 Counters *c; const s50::Book *book; Tracked(std::shared_ptr<s50::Prepared> p,Counters*counts):s50::Rules(p),c(counts),book(p->config.book){}
 template<class E> bool Cast(E&e,const rt::MacroLine&line,int pulses=0){s50::audit_reason=rt::ActionBlockReason::NONE;auto now=e.GetState().now;auto name=book->skills.at(line.action_slot).name;bool ok=s50::Rules::Cast(e,line,pulses);if(!ok){if(name=="拿云式"&&s50::audit_reason==rt::ActionBlockReason::MISSING_BUFF&&c->pending!=now){if(c->pending>=0) ++c->unresolved;c->rejected++;c->pending=now;}return false;}++c->accepted[string(name)];if(c->pending>=0){++c->delays[now-c->pending];++c->replies[string(name)];c->pending=-1;}return true;}
};
int main(int argc,char**argv){try{json q=json::parse(std::ifstream(argv[1]));auto cfg=JX3DPS::engine::Scenario(q.at("code").get<string>());q["config"].get_to(cfg);auto b=*cfg.book;cfg.book=&b;string text=q.contains("macro")?q.at("macro").get<string>():string(b.default_macro);auto [pg,err]=rt::MacroCompiler::Compile(text,rt::CatalogMacroOptions(b.Catalog()));if(!err.empty())throw std::runtime_error(err[0].message);auto data=std::make_shared<s50::Prepared>(*s50::Prepare(cfg));if(q.value("zero_shield_prepare",false)){auto i=std::ranges::find(b.skills,"盾飞",&rt::SkillDescriptor::name)-b.skills.begin();if(data->skills.at(i).cast_time!=6)throw std::runtime_error("shield not 6");data->skills[i].cast_time=0;}
 Counters counts;const int n=q.at("iterations"),frames=q.at("frames");rt::Simulation<Tracked> sim(pg.program,Tracked(data,&counts),60000,150000);json series=json::array();std::map<string,long long> hits;double mean=0,m2=0;for(int i=0;i<n;++i){counts.pending=-1;sim.Start(frames,rt::IterationSeed(42,i));sim.Run();if(counts.pending>=0)++counts.unresolved;auto total=sim.TotalDamage([&](auto&h,auto){++hits[string(b.skills[h.skill].name)];});series.push_back(total);auto d=total*16./frames,delta=d-mean;mean+=delta/(i+1);m2+=delta*(d-mean);}json out={{"mean",mean},{"se",sqrt(m2/(n-1)/n)},{"damages",series},{"hits",hits},{"accepted",counts.accepted},{"missing",counts.rejected},{"unresolved",counts.unresolved},{"delays",counts.delays},{"replies",counts.replies}};std::ofstream(argv[2])<<out.dump();}catch(std::exception&e){std::cerr<<e.what();return 1;}}
