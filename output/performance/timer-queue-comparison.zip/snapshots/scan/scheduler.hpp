#ifndef JX3DPS_RUNTIME_SCHEDULER_HPP
#define JX3DPS_RUNTIME_SCHEDULER_HPP

#include "../runtime.hpp"
#include <optional>
#include <stdexcept>

namespace JX3DPS::runtime {

enum class TimerKind : std::uint8_t { SkillCooldown, SkillPrepare, SkillCasting, BuffDuration, BuffInterval, MacroWake, Field, ResourceRegen, TeamApplication, TargetChange };
struct TimerHandle {
    TimerKind kind = TimerKind::SkillCooldown;
    Slot slot = INVALID_SLOT;
    bool target = false;
};

// One heap entry per timer. Re-arming neither allocates nor retains stale
// entries, even when a buff is refreshed millions of times before expiry.
class DeadlineQueue {
public:
    using TimerId = std::uint32_t;
    static constexpr TimerId INVALID_TIMER = std::numeric_limits<TimerId>::max();

    TimerId Create(TimerHandle handle, std::uint16_t priority = 0) {
        if (timers_.size() >= INVALID_TIMER) throw std::length_error("too many timers");
        auto id = static_cast<TimerId>(timers_.size());
        timers_.push_back({handle, 0, 0, INVALID_TIMER, priority});
        active_.reserve(timers_.size());
        return id;
    }

    void Arm(TimerId id, tick_t delay) {
        if (delay < 0 || delay > std::numeric_limits<tick_t>::max() - current_) {
            throw std::out_of_range("timer delay is out of range");
        }
        ArmAt(id, current_ + delay);
    }
    void ArmAt(TimerId id, tick_t deadline) {
        if (deadline < current_) throw std::out_of_range("timer is in the past");
        auto &timer = timers_.at(id);
        timer.deadline = deadline;
        timer.order = sequence_++;
        if (timer.position == INVALID_TIMER) {
            timer.position = static_cast<TimerId>(active_.size());
            active_.push_back(id);
        }
        if (active_.size() == 1) earliest_ = id;
        else if (earliest_ == id) earliest_ = INVALID_TIMER;
        else if (earliest_ != INVALID_TIMER && Before(id, earliest_)) earliest_ = id;
    }
    void Cancel(TimerId id) {
        auto &timer = timers_.at(id);
        if (timer.position != INVALID_TIMER) Remove(timer.position);
    }
    std::optional<tick_t> NextDelta() const {
        if (active_.empty()) return std::nullopt;
        return std::max<tick_t>(0, timers_[Earliest()].deadline - current_);
    }
    void Advance(tick_t delta) {
        if (delta < 0 || delta > std::numeric_limits<tick_t>::max() - current_) {
            throw std::out_of_range("clock advance is out of range");
        }
        if (auto next = NextDelta(); next && delta > *next) throw std::logic_error("cannot skip a pending event");
        current_ += delta;
    }

    template <typename Fn>
    void DispatchDue(Fn &&fn, std::size_t budget = 100000) {
        std::size_t dispatched = 0;
        while (!active_.empty() && timers_[Earliest()].deadline <= current_) {
            if (dispatched++ == budget) throw std::runtime_error("same-frame event budget exceeded");
            const auto id = Earliest();
            const auto handle = timers_[id].handle;
            Remove(timers_[id].position);
            fn(handle, id);
        }
    }
    tick_t Now() const { return current_; }
    std::size_t Pending() const { return active_.size(); }
    void Reset() {
        current_ = 0;
        sequence_ = 0;
        active_.clear();
        earliest_ = INVALID_TIMER;
        for (auto &timer : timers_) timer.position = INVALID_TIMER;
    }

private:
    struct Timer {
        TimerHandle handle;
        tick_t deadline;
        std::uint64_t order;
        TimerId position;
        std::uint16_t priority;
    };
    bool Before(TimerId lhs, TimerId rhs) const {
        const auto &a = timers_[lhs];
        const auto &b = timers_[rhs];
        if (a.deadline != b.deadline) return a.deadline < b.deadline;
        if (a.priority != b.priority) return a.priority < b.priority;
        return a.order < b.order;
    }
    TimerId Earliest() const {
        if (earliest_ != INVALID_TIMER) return earliest_;
        auto best = active_.front();
        for (std::size_t i = 1; i < active_.size(); ++i)
            if (Before(active_[i], best)) best = active_[i];
        earliest_ = best;
        return best;
    }
    void Remove(TimerId pos) {
        const auto removed = active_[pos];
        const auto moved = active_.back();
        active_.pop_back();
        timers_[removed].position = INVALID_TIMER;
        if (removed == earliest_) earliest_ = INVALID_TIMER;
        if (pos < active_.size()) {
            active_[pos] = moved;
            timers_[moved].position = pos;
        }
    }

    mutable TimerId earliest_ = INVALID_TIMER;
    tick_t current_ = 0;
    std::uint64_t sequence_ = 0;
    std::vector<Timer> timers_;
    std::vector<TimerId> active_;
};

} // namespace JX3DPS::runtime
#endif
