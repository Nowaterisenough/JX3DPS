from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import itertools,subprocess,json,ctypes,re,statistics
p=Path(__file__).resolve().parent
versions=['binary','hole_key','scan'];compilers={'clang':'clang++','gcc':'g++'};specs={'tx':'tai_xu_runtime','mw':'mo_wen_runtime'}
def build(args):
 c,v,s=args;subprocess.run([compilers[c],'-O3','-DNDEBUG','-std=gnu++26','-I',str(p/v),str(Path('apps/cli')/(specs[s]+'.cpp')),'-o',str(p/(c+'-'+v+'-'+s+'.exe'))],check=True)
with ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(build,itertools.product(compilers,versions,specs)))
configs={'tx':[],'mw':[],'tx_buffs':['--talents','dieren,wuyi,shenmai,xuanmen,lieyun,guchang','--equipment','weapon_cw,set_attribute','--attribute','overcome_base=20000','--attribute','overcome_by_class=5000','--team-buffs','ji_lei:0:96:1;nong_mei:48:96:1;hao_ling_san_jun:16:0:48;po_feng:32:160:1'],'mw_equipped':['--talents','haozhong,feifan,shixiang,zhenglv,liuzhao,kemeng','--equipment','shoes,wrist,belt,set_attribute,set_skill,weapon_cw,weapon_water','--team-effects','you_ren,jingmiao']}
ref={r['scene']:r['checksum'] for r in json.loads((p/'final-timings.json').read_text())};rows=[]
k=ctypes.windll.kernel32;k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(ctypes.c_void_p(-1),4)
for i,order in enumerate(itertools.permutations(versions)):
 for c in (['gcc','clang'] if i%2 else ['clang','gcc']):
  for v in order:
   for scene,options in configs.items():
    text=subprocess.check_output([str(p/(c+'-'+v+'-'+scene.split('_')[0]+'.exe')),'--workers','1','--seconds','300','--iterations','2048','--seed','42',*options],text=True,encoding='utf-8');check,elapsed=re.search(r'checksum=(\d+) elapsed_s=([\d.]+)',text).groups();assert check==ref[scene],(scene,check,ref[scene]);rows.append(dict(round=i,compiler=c,variant=v,scene=scene,us=float(elapsed)*1e6/2048))
 (p/'final-cli-timings.json').write_text(json.dumps(rows,indent=2));print('CLI round',i+1,flush=True)
for c in compilers:
 for scene in configs:print(c,scene,[round(statistics.median(r['us'] for r in rows if (r['compiler'],r['scene'],r['variant'])==(c,scene,v)),2) for v in versions]);
