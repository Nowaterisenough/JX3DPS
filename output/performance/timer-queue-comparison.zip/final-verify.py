from pathlib import Path
from contextlib import ExitStack
import struct,subprocess,json
p=Path(__file__).resolve().parent
scenes=['tx','mw','tx_buffs','mw_equipped']; counts={}
for c in ['clang','gcc']:
 with ExitStack() as stack:
  procs=[stack.enter_context(subprocess.Popen([str(p/(c+'-'+v+'.exe')),'trace','2048'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)) for v in ('binary','hole_key','scan')];totals={}
  for scene in scenes:
   for i in range(2048):
    sizes=[q.stdout.read(4) for q in procs];assert len(sizes[0])==4 and sizes[1:]==sizes[:1]*2,(c,scene,i,sizes)
    n=struct.unpack('=I',sizes[0])[0];vals=[q.stdout.read(n) for q in procs];assert len(vals[0])==n and vals[1:]==vals[:1]*2,(c,scene,i,'different trace');assert struct.unpack_from('=I',vals[0])[0]==i
   print(c,scene,'2048 exact traces',flush=True)
  for q in procs:assert not q.stdout.read(1) and q.wait()==0
  messages=[q.stderr.read().decode().strip() for q in procs];assert len(set(messages))==1;print(messages[0],flush=True)
  for line in messages[0].splitlines():
   scene,*rest=line.split();totals[scene]={k:int(v) for k,v in (t.split('=') for t in rest)}
  counts[c]=totals
(p/'final-parity.json').write_text(json.dumps(counts,indent=2))
