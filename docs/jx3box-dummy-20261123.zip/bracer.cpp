#include "src/engine/engine.cpp"
#include <fstream>
#include <iostream>
int main(int argc, char** argv) {
    if (argc != 3) return 1;
    try {
        Json q = Json::parse(std::ifstream(argv[1]));
        auto cfg = engine::Scenario(q.at("scenario").get<std::string>());
        q.at("config").get_to(cfg);
        auto book = *cfg.book;
        cfg.book = &book;
        const auto skill = std::ranges::find(book.skills, "巽·晚山青", &rt::SkillDescriptor::name);
        if (skill == book.skills.end()) return 2;
        auto& bracer = book.hits.at(skill - book.skills.begin());
        if (!bracer.fixed_equipment_damage || bracer.fixed != 46000) return 3;
        bracer.fixed = q.at("bracerBase").get<int>();  // 40789 item base. The original engine handles the trigger, cooldown and mitigation.
        jx3dps_engine session;
        std::ofstream(argv[2]) << nativeBatch(session, q, cfg, book.Catalog()).dump();
    } catch (const std::exception& e) { std::cerr << e.what(); return 4; }
}

