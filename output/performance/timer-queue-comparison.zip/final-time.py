import ctypes,itertools,random,subprocess,json,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
k=ctypes.WinDLL('kernel32',use_last_error=True);k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t];assert k.SetProcessAffinityMask(ctypes.c_void_p(-1),4)
versions=['binary','hole_key','scan'];perms=list(itertools.permutations(versions));rnd=random.Random(42);rows=[];checks={}
for block in range(2):
 rnd.shuffle(perms)
 for i,order in enumerate(perms):
  for c in (['clang','gcc'] if i%2==0 else ['gcc','clang']):
   for v in order:
    output=subprocess.check_output([str(p/(c+'-'+v+'.exe')),'time','2048'],text=True)
    for line in output.splitlines():
     scene,us,checksum,warm=line.split();assert checks.setdefault(scene,(checksum,warm))==(checksum,warm);rows.append(dict(round=block*6+i,compiler=c,variant=v,scene=scene,us=float(us),checksum=checksum))
  (p/'final-timings.json').write_text(json.dumps(rows,indent=2));print('timing round',block*6+i+1,flush=True)
for c in ['clang','gcc']:
 for scene in checks:
  a={v:statistics.median([r['us'] for r in rows if (r['compiler'],r['variant'],r['scene'])==(c,v,scene)]) for v in versions};print(c,scene,a,flush=True)
